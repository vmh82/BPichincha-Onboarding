﻿
using CreditoAuto.Domain.Interfaces;
using CreditoAuto.Entities.Mapper;
using CreditoAuto.Entities.Models;
using CreditoAuto.Repository;
using CreditoAuto.Repository.Context;
using Mapster;
using Microsoft.Extensions.Configuration;
using Moq;
using NUnit.Framework;
using System.Threading.Tasks;

namespace CreditoAuto.UnitTest
{
    [TestFixture]
    public class SolicitudCreditoTest
    {
        private CreditoAutoDbContext mocKContext;
        private IConfiguration _configuration;
        private Mock<IVehiculoRepository> _vehiculoRepository; 
        private Mock<ISolicitudCreditoRepository> _solicitudCreditoRepository;

        [OneTimeSetUp]
        public void Setup()
        {
            TypeAdapterConfig configMapper = MapperConfig.ConfigurarMapper();

            mocKContext = new MockCreditoAutoDbContext().InicializarContexto();
            _configuration = new MockConfiguracionDocumentos().InicializarConfiguration();
            new InicializarDocumentos(mocKContext, _configuration).Inicializar();
            _vehiculoRepository = new Mock<IVehiculoRepository>(mocKContext);
            ///preparacion
            Vehiculo vehiculo = new Vehiculo
            {
                MarcaId = 1,
                Modelo = "Verna",
                Cilindraje = 1.455M,
                Avaluo = 17500M,
                NumeroChasis = "123123123132",
                Placa = "PSP665",
                Tipo = "Sedan"
            };
            _vehiculoRepository.Setup(q=>q.Crear(vehiculo)).ReturnsAsync(1);
            _solicitudCreditoRepository = new Mock<ISolicitudCreditoRepository>(mocKContext);
        }

        [Test]
        public async Task CrearSolicitudCredito_Nueva()
        {
            SolicitudCredito solicitud = new SolicitudCredito
            {
                IdentificacionCliente = "1111",
                NumeroPuntoVenta = 11234,
                Placa = "4444",
                MesesPlazo = 24,
                Cuotas = 5,
                Entrada = 1250M,
                IdentificacionEjecutivo = "545",
                Observacion = "ssss",
                Estado = 1,
            };
            SolicitudCreditoRepository solicitudRepository = new SolicitudCreditoRepository(mocKContext);
            int esFinTransaccion = await solicitudRepository.Crear(solicitud);
        }

        [Test]
        public async Task Verificar_Existe_Cliente_Creacion_Solicitud()
        {
            //SolicitudCredito solicitud = new SolicitudCredito
            //{
            //    IdentificacionCliente = "1111",
            //    NumeroPuntoVenta = 11234,
            //    Placa = "4444",
            //    MesesPlazo = 24,
            //    Cuotas = 5,
            //    Entrada = 1250M,
            //    IdentificacionEjecutivo = "545",
            //    Observacion = "ssss",
            //    Estado = 1,
            //};
            // _solicitudCreditoRepository.Setup(q=>q.Consultar(solicitud.IdentificacionCliente)).ReturnsAsync(solicitud);
            //int esFinTransaccion = await _solicitudCreditoRepository.Crear(solicitud);
        }
    }
}
