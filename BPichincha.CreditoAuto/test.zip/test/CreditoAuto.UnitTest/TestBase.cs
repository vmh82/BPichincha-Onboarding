﻿using CreditoAuto.Repository;
using CreditoAuto.Repository.Context;
using Microsoft.Extensions.Configuration;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreditoAuto.UnitTest
{
    public  class TestBase
    {
        public CreditoAutoDbContext mocKContext;
        public IConfiguration _configuration;

        [SetUp]
        public virtual void SetUp()
        {
            mocKContext = new MockCreditoAutoDbContext().InicializarContexto();
            _configuration = new MockConfiguracionDocumentos().InicializarConfiguration();
            new InicializarDocumentos(mocKContext, _configuration).Inicializar();
        }
    }
}
